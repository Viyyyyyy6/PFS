public class Result extends Java{
    double result;
    public void Percentage(){
        result =(score/10)*100;
        System.out.println("Total of Correct Answer: "+ score);
        System.out.println("Total of Incorrect Answer: "+ wrongAnswer);
        System.out.println();
        System.out.println("Your Total Result: "+ result +"%");
        System.out.println();                                                  // i use inheritance to gett the result of correct answer and incoorect answer
        if(result >= 60){
            System.out.println("Congratulations You passed  :)) ");
        }
        else if(result <= 60){
            System.out.println("Sorry You Failed!!  Better Luck Next Time!! :( ");
        }else{
            System.out.println("Oww noo!! Better Luck Next Time!! ");
        }

    }

}