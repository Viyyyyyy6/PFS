import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Java {
    public static double score;
    public static double wrongAnswer;

    public static void main(String[] args) throws FileNotFoundException {


        File f1 = new File("HTML.csv");
        File f2 = new File("JAVA.csv");
        File f3 = new File("JAVA-BASICS.csv");
        String f1str = f1.getPath();
        String f2str = f2.getPath();
        String f3str = f3.getPath();
        System.out.println("\t           ***************WELCOME TO MCQ TEST!***************\n\t          ---------------LET'S START THE FUN!---------------\n");
        String[] line_array;
        System.out.print("Enter your full name along with the learner's ID: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        System.out.println("Hello Learner " + name + ", please choose your Multiple Choice Question Set. These are the Options :p\n (Enter the number of your choice) :");
        System.out.println("1.) " + f1str.replace(".csv", ""));
        System.out.println("2.) " + f2str.replace(".csv", ""));
        System.out.println("3.) " + f3str.replace(".csv", ""));
        int choice = sc.nextInt();
        if (choice == 1) {

            System.out.println("Learner " + name + " have chosen 1, HTML Set of Questions");
            System.out.println("\nPlease choose the best best choice for the questions provided. 😛");
            Scanner MCQ1 = new Scanner(f1);
            while (MCQ1.hasNextLine()) {
                String line = MCQ1.nextLine();
                line_array = line.split(",");
                System.out.println();
                System.out.println(line_array[0]);
                System.out.println("\ta.)" + " " + line_array[1]);
                System.out.println("\tb.)" + " " + line_array[2]);
                System.out.println("\tc.)" + " " + line_array[3]);
                System.out.println("\td.)" + " " + line_array[4]);
                System.out.println();
                System.out.print("Enter your answer here: ");

                String correctAnswer;
                correctAnswer = line_array[5].trim();

                String userAnswer = sc.next();
                if (userAnswer.equalsIgnoreCase(line_array[5])) {
                    System.out.println("\t Your answer is right! ");
                    score++;
                } else {
                    System.out.println("\t Oh no, Your answer is wrong.   The correct answer is:  " + line_array[5]);
                    wrongAnswer++;
                }

            }

        } else if (choice == 2) {

            System.out.println("Learner " + name + " have chosen number 2, JAVA Set of Questions");
            Scanner MCQ2 = new Scanner(f2);
            while (MCQ2.hasNextLine()) {
                String line = MCQ2.nextLine();
                line_array = line.split(",");
                System.out.println("\nPlease choose the best best choice for the questions provided. 😛");
                System.out.println();
                System.out.println(line_array[0]);
                System.out.println("\ta.)" + " " + line_array[1]);
                System.out.println("\tb.)" + " " + line_array[2]);
                System.out.println("\tc.)" + " " + line_array[3]);
                System.out.println("\td.)" + " " + line_array[4]);

                System.out.print("Enter your answer here: ");
                String correctAnswer = line_array[5];

                String userAnswer = sc.next();
                if (userAnswer.equalsIgnoreCase(line_array[5])) {
                    System.out.println("Your answer is right!");
                    score++;
                } else {
                    System.out.println("Oh no, Your answer is wrong.  The correct answer is:  " + line_array[5]);
                    wrongAnswer++;
                }

            }

        } else if (choice == 3) {

            System.out.println("You, " + name + " have chosen 3, JAVA BASICS Set of Questions");
            Scanner MCQ3 = new Scanner(f3);
            while (MCQ3.hasNextLine()) {
                String line = MCQ3.nextLine();
                line_array = line.split(",");
                System.out.println("\nPlease choose the best best choice for the questions provided. 😛");
                System.out.println();
                System.out.println(line_array[0]);
                System.out.println("\ta.)" + " " + line_array[1]);
                System.out.println("\tb.)" + " " + line_array[2]);
                System.out.println("\tc.)" + " " + line_array[3]);
                System.out.println("\td.)" + " " + line_array[4]);

                System.out.print("Enter your answer here: ");
                String correctAnswer = line_array[5];

                String userAnswer = sc.next();
                if (userAnswer.equalsIgnoreCase(line_array[5])) {
                    System.out.println("Your answer is right!");
                    score++;
                } else {
                    System.out.println("Oh no, Your answer is wrong.   The correct answer is:  " + line_array[5]);
                    wrongAnswer++;
                }
                System.out.println();
            }

        }
        Result result = new Result();
        result.Percentage();

    }
}

